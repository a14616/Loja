const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Substitua 'your_connection_string' pela sua URI de conexão real do MongoDB Atlas
const uri = 'mongodb+srv://a14616:<Abcd0608>@cluster0.yup5608.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(uri)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log('MongoDB connection error:', err));

const productSchema = new mongoose.Schema({
  newarrival: Boolean,
  favourite: Boolean,
  title: String,
  category: String,
  introduction: String,
  price: Number,
});

const newsletterSchema = new mongoose.Schema({
  email: String,
});

const Product = mongoose.model('Product', productSchema);
const Newsletter = mongoose.model('Newsletter', newsletterSchema);

app.get('/newarrivals', async (req, res) => {
  try {
    const newArrivals = await Product.find({ newarrival: true }).limit(3);
    res.json(newArrivals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/favourites', async (req, res) => {
  try {
    const favourites = await Product.find({ favourite: true }).limit(2);
    res.json(favourites);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/newsletter', async (req, res) => {
  try {
    const { email } = req.body;
    const newSubscription = new Newsletter({ email });
    await newSubscription.save();
    res.json({ message: 'Email added to newsletter' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
